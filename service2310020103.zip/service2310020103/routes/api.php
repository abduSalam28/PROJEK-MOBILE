<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;



use App\Http\Controllers\BukuController;
use App\Http\Controllers\PenggunaBukuContoller;

Route::apiResource('bukus', BukuController::class);
Route::apiResource('pengguna_bukus', PenggunaBukuContoller::class);