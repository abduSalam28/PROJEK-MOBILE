<?php

namespace App\Http\Controllers;

use App\Models\PenggunaBuku;
use Illuminate\Http\Request;

class PenggunaBukuContoller extends Controller
{
    
    public function index()
    {
        return PenggunaBuku::all();
    }

  
    public function store(Request $request)
    {
        $request->validate([
            'no_pinjam' => 'required|unique:pengguna_bukus',
            'buku_id' => 'required|integer',
            'tanggal_peminjaman' => 'required|date',
            'tanggal_pengembalian' => 'required|date',
        ]);

        return PenggunaBuku::create($request->all());
    }

    
    public function show($id)
    {
        return PenggunaBuku::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $pengguna_bukus = PenggunaBuku::findOrFail($id);
        $request->validate([
            'no_pinjam' => 'sometimes|required|unique:pengguna_bukus,no_pinjam,' . $pengguna_bukus->id,
        ]);
        $pengguna_bukus->update($request->all());
        return $pengguna_bukus;
    }

    public function destroy($id)
    {
        $pengguna_bukus = PenggunaBuku::findOrFail($id);
        $pengguna_bukus->delete();
        return response()->noContent();
    }
}
