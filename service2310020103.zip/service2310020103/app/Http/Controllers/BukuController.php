<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;

class BukuController extends Controller
{

    public function index()
    {
        return Buku::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'kode_buku' => 'required|unique:bukus',
            'nama_buku' => 'required|string',
            'pengarang' => 'required|string',
            'penerbit' => 'required|string',
            'tahun_terbit' => 'required|date',
            'jumlah_buku' => 'required|integer',
        ]);

        return Buku::create($request->all());
    }


    public function show($id)
    {
        return Buku::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $bukus = Buku::findOrFail($id);
        $request->validate([
            'kode_buku' => 'sometimes|required|unique:bukus,kode_buku,' . $bukus->id,
        ]);
        $bukus->update($request->all());
        return $bukus;
    }


    public function destroy($id)
    {
        $bukus = Buku::findOrFail($id);
        $bukus->delete();
        return response()->noContent();
    }
}
