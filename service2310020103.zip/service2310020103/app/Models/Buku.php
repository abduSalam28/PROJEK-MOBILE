<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Buku extends Model
{
    use HasFactory;
    protected $table = 'bukus';
    protected $fillable = [
        'kode_buku',
        'nama_buku',
        'pengarang',
        'penerbit',
        'tahun_terbit',
        'jumlah_buku',
    ];
}
