<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PenggunaBuku extends Model
{
    use HasFactory;
    protected $table = 'pengguna_bukus';
    protected $fillable = [
        'no_pinjam',
        'buku_id',
        'tanggal_peminjaman',       
        'tanggal_pengembalian',
    ];
}
